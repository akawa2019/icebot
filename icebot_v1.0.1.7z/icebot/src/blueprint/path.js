const BluePrint = require("./blueprint");

class Line {
    dig;
    targetX;
    targetZ;

    /**
     *
     * @param {boolean} dig
     * @param {Line} last
     * @param {number} deltaX
     * @param {number} deltaZ
     */
    constructor(dig, last, deltaX, deltaZ) {
        this.dig = dig;
        this.targetX = last.targetX + deltaX;
        this.targetZ = last.targetZ + deltaZ;
    }
}

class Path {
    name;
    is;
    origin;
    count;
    stage;
    facing;
    /**
     * @type {Line[]}
     */
    lines;

    /**
     * 通过蓝图构建工作路径
     * @param {BluePrint} blueprint
     */
    constructor(blueprint) {
        this.stage = 0;
        this.origin = blueprint.origin;
        this.name = blueprint.name;
        this.is = blueprint.is;
        this.loop = 0;
        this.extra = blueprint.extra;
        this.geometry = {};
        this.geometry.workLoop = blueprint.workLoop;

        const feedshift = blueprint.nextStartPoint.minus(blueprint.endPoint);
        if (feedshift.iszero()) throw new Error("进给距离为 0");
        if (!feedshift.orthogonality()) throw new Error("进给不沿坐标轴");
        this.lines = [
            {
                dig: false,
                targetX: blueprint.startPoint.x,
                targetZ: blueprint.startPoint.z,
            },
            {
                dig: true,
                targetX: blueprint.endPoint.x,
                targetZ: blueprint.endPoint.z,
            },
        ]; // 第一次主运动是特殊的

        if (feedshift.x == 0) {
            // 沿Z进给
            const feed = feedshift.z;
            this.facing = feed > 0 ? Math.PI : 0;
            const oZ = blueprint.origin.z;
            if (oZ != blueprint.startPoint.z || oZ != blueprint.endPoint.z) {
                throw new Error("主运动无法定义或与进给不垂直");
            }
            const work = blueprint.endPoint.x - blueprint.startPoint.x;
            this.geometry.workLength = Math.abs(work);
            this.geometry.feedLength = Math.abs(feed);
            for (let i = 1; i < blueprint.workLoop; i++) {
                this.lines.push(new Line(false, this.lines.at(-1), 0, feed));
                let direction = i % 2 ? -1 : 1;
                this.lines.push(
                    new Line(true, this.lines.at(-1), direction * work, 0),
                );
            }
        } else {
            // 沿X进给
            const feed = feedshift.x;
            this.facing = feed > 0 ? -Math.Pi / 2 : Math.PI / 2;
            const oX = blueprint.origin.x;
            if (oX != blueprint.startPoint.x || oX != blueprint.endPoint.x) {
                throw new Error("主运动无法定义或与进给不垂直");
            }
            const work = blueprint.endPoint.z - blueprint.startPoint.z;
            this.geometry.workLength = Math.abs(work);
            this.geometry.feedLength = Math.abs(feed);
            for (let i = 1; i < blueprint.workLoop; i++) {
                this.lines.push(new Line(false, this.lines.at(-1), feed, 0));
                let direction = i % 2 ? -1 : 1;
                this.lines.push(
                    new Line(true, this.lines.at(-1), 0, direction * work),
                );
            }
        }

        this.count = this.lines.length;
    }

    /**
     * 计算工作和进给路径长度，当给出速度时计算时间
     * @param {{dig:number, feed:number}} speed
     */
    geometrySummary(speed) {
        let ret = {};
        ret.digPathLength = this.geometry.workLength * this.geometry.workLoop;
        ret.feedPathLength =
            this.geometry.feedLength * (this.geometry.workLoop - 1) +
            Math.sqrt(
                (this.lines[0].targetX - this.origin.x) ** 2 +
                    (this.lines[0].targetZ - this.origin.z) ** 2,
            );
        if ("dig" in speed && "feed" in speed) {
            ret.digTime = ret.digPathLength / speed.dig;
            ret.feedTime = ret.feedPathLength / speed.feed;
            ret.loopTime =
                ret.digTime + ret.feedTime + (ret?.extra?.loopDelay ?? 0);
        }
        return ret;
    }

    /**
     * 根据给定的修正系数和已有几何参数推测产量
     * @param {number} workLengthCorrection 工作长度修正值(冰面长度与工作长度的差距)
     * @param {number} iceWidth 冰面宽度
     * @param {number} loopTime 挖冰总周期(s)
     */
    productionSummary(workLengthCorrection, iceWidth, loopTime) {
        let ret = {};
        ret.iceArea =
            (this.geometry.workLength - workLengthCorrection) *
            iceWidth *
            this.geometry.workLoop;
        ret.iceProbability = 1 - (4095 / 4096) ** (loopTime * 20);
        // 31 * 4的冰场或许可以使用中心极限定理？但愿吧，我懒得写二项分布了
        return ret;
    }
}

module.exports = { Line, Path };
