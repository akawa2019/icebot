const Vec3 = require("vec3").Vec3;

module.exports = class PointXZ {
    x;
    z;

    /**
     * @param {number} x will be floored to int
     * @param {number} z will be floored to int
     */
    constructor(x, z) {
        this.x = Math.floor(x);
        this.z = Math.floor(z);
    }

    /**
     * @param {Vec3} vec3
     */
    static fromVec3(vec3) {
        return new PointXZ(vec3.x, vec3.z);
    }

    toVec3(y = 0) {
        return new Vec3(this.x, y, this.z);
    }

    /**
     * @param {number} x
     * @param {number} z
     */
    offset(x, z) {
        return new PointXZ(this.x + x, this.z + z);
    }

    /**
     * @param {PointXZ} pt
     */
    minus(pt) {
        return new PointXZ(this.x - pt.x, this.z - pt.z);
    }

    /**
     * @param {PointXZ} pt
     */
    add(pt) {
        return new PointXZ(this.x + pt.x, this.z + pt.z);
    }

    static fromAny(obj) {
        return new PointXZ(parseFloat(obj.x), parseFloat(obj.z));
    }

    orthogonality() {
        return this.x == 0 || this.z == 0;
    }

    iszero() {
        return this.x == 0 && this.z == 0;
    }

    isNaN() {
        return isNaN(this.x) || isNaN(this.z);
    }

    static equal(p1, p2) {
        return p1.x == p2.x && p1.z == p2.z;
    }
};
