const { existsSync, writeFileSync, mkdirSync } = require("fs");
const { line2words } = require("../util");
const PointXZ = require("./pointxz");
const BluePrint = require("./blueprint");
const { Path } = require("./path");
const RL = require("readline").promises.createInterface(
    process.stdin,
    process.stdout,
);
const speed = require("../../config.json")?.bot?.speed;

console.log("ICE BOT blueprint creator CLI 1.0");
console.log("请您依次输入以下参数来定义冰机");
console.log("在输入坐标时，输入两个数字 X 和 Z ,用空格分开\n\n");

module.exports = async () => {
    const data = new BluePrint();

    // name
    do {
        data.name = await RL.question("冰机名称 -> ");
    } while (data.name.length == 0);

    // is
    do {
        let answer = await RL.question("所在岛屿编号 -> ");
        if (answer.startsWith("#")) answer = answer.slice(1);
        data.is = parseInt(answer);
    } while (isNaN(data.is));

    // origin
    do {
        data.origin = await tryGetPoint("原点坐标");
    } while (data.origin == undefined);

    // startPoint
    do {
        data.startPoint = await tryGetPoint("挖冰起点坐标");
    } while (data.startPoint == undefined);

    // endPoint
    do {
        data.endPoint = await tryGetPoint("挖冰终点坐标");
    } while (data.endPoint == undefined);

    // nextStartPoint
    do {
        data.nextStartPoint = await tryGetPoint("第二次起点坐标");
    } while (data.nextStartPoint == undefined);

    // nextStartPoint
    do {
        let answer = line2words(
            await RL.question("工作循环次数(每一轮一共挖几条冰) -> "),
        );
        data.workLoop = parseInt(answer);
    } while (isNaN(data.workLoop));

    let path;
    try {
        path = new Path(data);
    } catch (e) {
        console.error("输入参数有误 : " + e.message);
        process.exit(1);
    }

    console.clear();
    console.log("已完成参数定义，检查以下参数是否正确:\n");
    console.log(JSON.stringify(data, undefined, "\t"));
    console.log("\n\n");

    let filename = undefined;
    if (!existsSync("./blueprints")) mkdirSync("./blueprints");
    while (1) {
        const answer = await RL.question("保存文件名 -> ");
        if (answer.length == 0) continue;
        filename = "./blueprints/" + answer + ".json";
        if (existsSync(filename)) {
            console.error("已经存在同名文件 : " + answer);
            continue;
        }
        break;
    }
    writeFileSync(filename, JSON.stringify(data));
    console.clear();
    console.log("定义文件已保存到 " + filename);

    console.log("\n\n根据冰机参数得到的运行情况如下:\n");
    const times = path.geometrySummary(speed);
    console.log(`挖掘路径长度 : ${times.digPathLength}m`);
    console.log(`进给路径长度 : ${times.feedPathLength}m`);
    if (times.digTime) {
        const digmin = Math.floor(times.digTime / 60);
        const feedmin = Math.floor(times.feedTime / 60);
        const loopmin = Math.floor(times.loopTime / 60);
        console.log(
            `挖掘时间 : ${digmin}min ${Math.round(times.digTime - 60 * digmin)}s`,
        );
        console.log(
            `进给时间 : ${feedmin}min ${Math.round(times.feedTime - 60 * feedmin,)}s`,
        );
        console.log(
            `循环时间 : ${loopmin}min ${Math.round(times.loopTime - 60 * loopmin)}s`,
        );
        console.log(
            `工作比 : ${(times.digTime / times.loopTime*100).toFixed(2)}%`,
        );

        console.warn("\n可以关闭本程序了,也可输入下列参数计算理论产能");
        let workLengthCorrection = 0;
        do {
            let answer = await RL.question(
                "工作长度比实际冰面长度长多少 (即考虑两侧和中间接缝处不能挖冰的长度) -> ",
            );
            workLengthCorrection = parseInt(answer);
        } while (isNaN(workLengthCorrection) || workLengthCorrection < 0);
        let ice_width = 4;
        do {
            let answer = await RL.question(
                "冰面宽度 (即每1m工作长度结几块冰，一般是4) -> ",
            );
            ice_width = parseInt(answer);
        } while (isNaN(workLengthCorrection) || 0 > ice_width || ice_width > 5);

        const production = path.productionSummary(
            workLengthCorrection,
            ice_width,
            times.loopTime,
        );
        console.warn("\n\n以下产量为最大值, 实际受收集率等多方面影响\n");
        console.log(`冰面面积 : ${production.iceArea}`);
        console.log(
            `循环凝结率 : ${production.iceProbability.toFixed(4)}`,
        );
        const max =
            ((production.iceArea * production.iceProbability) /
                times.loopTime) *
            60;
        console.log(
            `平均最大产量 : ${max.toFixed(1)}/min (${(max * 0.06).toFixed(2)}k/h)`,
        );

        if (production.iceProbability < 0.95) {
            console.warn(
                "\n\n该冰机的循环凝结率小于 0.95。在第二次及之后的循环中，会存在很多水方块，造成收集水流被干扰，大幅度降低收集率，建议为其设置循环等待时间",
            );
            console.log(
                "根据预计工作时间计算了凝结率达到一定值时所需的延时，您可权衡产率和收率自行选择:",
            );
            const tr = (td1, td2, td3) =>
                console.log(`\t${td1}\t\t${td2}\t\t${td3}`);
            tr("凝结率", "循环延时", "理论产量(min)");
            [
                0.95, 0.96, 0.97, 0.98, 0.985, 0.99, 0.9925, 0.995, 0.9975,
                0.999,
            ].forEach((val) => {
                const totaltime =
                    Math.log(1 - val) / Math.log(4095 / 4096) / 20;
                tr(
                    val,
                    Math.round(totaltime - times.feedTime - times.digTime),
                    Math.round((production.iceArea / totaltime) * 6000) / 100,
                );
            });

            console.log(
                "\n更改方式: 冰机定义文件新建或修改属性 extra.loopDelay 为循环延时的数值",
            );
        }
    } else {
        console.log("因未能正确读取config.json中的bot.speed, 无法计算时间信息");
    }
};

async function tryGetPoint(question) {
    let answer = line2words(await RL.question(question + " -> "));
    if (answer.length != 2) return undefined;
    let ret = new PointXZ(parseFloat(answer[0]), parseFloat(answer[1]));
    if (ret.isNaN()) return undefined;
    return ret;
}
