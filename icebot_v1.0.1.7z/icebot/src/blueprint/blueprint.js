const PointXZ = require("./pointxz");

module.exports = class BluePrint {
    /**
     * @type {string}
     */
    name;
    /**
     * @type {number}
     */
    is;
    /**
     * @type {PointXZ}
     */
    origin;
    /**
     * @type {PointXZ}
     */
    startPoint;
    /**
     * @type {PointXZ}
     */
    endPoint;
    /**
     * @type {PointXZ}
     */
    nextStartPoint;
    /**
     * @type {number}
     */
    workLoop;

    static fromAny(obj) {
        let ret = new BluePrint();
        ret.name = obj.name;
        ret.is = parseInt(obj.is);
        ret.workLoop = parseInt(obj.workLoop);
        ret.origin = PointXZ.fromAny(obj.origin);
        ret.startPoint = PointXZ.fromAny(obj.startPoint);
        ret.endPoint = PointXZ.fromAny(obj.endPoint);
        ret.nextStartPoint = PointXZ.fromAny(obj.nextStartPoint);
        ret.extra = obj.extra ?? {};

        for (const prop in ret) if (ret[prop] == undefined) throw new Error();
        return ret;
    }
};
