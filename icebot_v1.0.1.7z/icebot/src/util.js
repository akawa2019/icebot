const Vec3 = require("vec3").Vec3;
/**
 * Fix the point to the center of a block's XZ plain
 * @param {import("vec3").Vec3} vec3
 */
function centered(vec3) {
    return new Vec3(Math.floor(vec3.x) + 0.5, vec3.y, Math.floor(vec3.z) + 0.5);
}

/**
 * get a promise that will resolve at given time
 * @param {number} ms
 * @returns {Promise<void>}
 */
function delay(ms) {
    return new Promise((resolve) => setTimeout(() => resolve(), ms));
}

/**
 * @param {string} line
 * @returns
 */
function line2words(line) {
    return line.trim().split(/\s+/);
}

module.exports = { centered, delay, line2words };
