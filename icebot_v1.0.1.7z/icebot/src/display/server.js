const Thread = require("worker_threads");
const maxPtLen = 180;

if (!Thread.isMainThread) {
    const { readFile } = require("fs");
    const Http = require("http");

    process.program = Thread.workerData;
    require("../log");

    function onDataGot(rawdata) {
        const production = rawdata.production.map(
            (val, i) => val - rawdata.production[i - 1],
        );
        if (rawdata.production.length > maxPtLen) {
            const trimlen = rawdata.production.length - maxPtLen;
            rawdata.firstMin += trimlen * 60000;
            production.splice(0, trimlen);
            rawdata.durability.splice(0, trimlen);
        }
        else {
            production[0] = rawdata.production[0];
        }
        rawdata.production = production;
        return rawdata;
    }

    const server = Http.createServer((req, res) => {
        if (req.method == "GET") {
            switch (req.url) {
                case "/favicon.ico":
                    sendStaticResource("./src/display/favicon.ico", res, "image/x-icon");
                    break;
                case "/":
                    sendStaticResource("./src/display/index.html", res, "text/html; charset=UTF-8");
                    break;
                case "/log":
                    sendStaticResource("./src/display/logindex.html", res, "text/html; charset=UTF-8");
                    break;
                case "/logdata":
                    sendStaticResource(process.env.ICEBOT_LOGFILE_NAME, res, "text/plain; charset=UTF-8");
                    break;
                case "/data":
                    Thread.parentPort.once("message", (message) => {
                        const reply = JSON.stringify(onDataGot(message));
                        res.writeHead(200).end(reply);
                        console.debug(
                            `对 ${res.socket.remoteAddress.slice(7)} 发送了 ${reply.length}byte 历史数据`,
                        );
                    });
                    Thread.parentPort.postMessage({ type: "getdata" });
                    break;
                default:
                    res.writeHead(404).end();
                    console.warn(`<server> 服务器接收到 ${res.socket.remoteAddress.slice(7)} 的非法请求路径 ${req.url}`);
            }
        } else res.writeHead(405).end();
    }).listen(process.program.reportPort);
    console.log(`在本地端口 ${process.program.reportPort} 开启产量报告服务器`);

    function sendStaticResource(file, res, contentType) {
        readFile(file, (err, data) => {
            if (err) res.writeHead(404).end();
            else res.writeHead(200, { "Content-Type": contentType }).end(data);
        });
    }
}



function onDataRequest(icebot) {
    return {
        timeStamp: Date.now(),
        worker: icebot.config.username,
        taskname: icebot.path.name,
        loopCount: icebot.path.loop,
        startTime: icebot.history.startTime,
        amount: icebot.history.counter,
        production: icebot.history.production,
        durability: icebot.history.durablity,
        tool: icebot.bot.heldItem.name,
        firstMin: icebot.history.firstMin,
    };
}

/**
 * 在单独的线程启动产量报告服务器
 * @param {import("../botcore/icebot")} icebot
 */
module.exports = (icebot) => {
    if (Thread.isMainThread) {
        const server_thread = new Thread.Worker(__filename, {
            workerData: process.program,
        });
        process.on("exit", () => {
            server_thread.terminate();
        });
        server_thread.on("message", (message) => {
            switch (message.type) {
                case "getdata":
                    server_thread.postMessage(onDataRequest(icebot));
                    console.debug("服务器进程获取了信息");
                    break;
                default:
                    console.error("接收到服务器进程的未知消息类型 : " + message.type);
            }
        });
    }
};
