const fs = require("fs");

const config = require("../../config.json");
const checkConfig = require("./paramcheck");
try{
    checkConfig(config);
}
catch (eAssert){
    console.error("参数检查错误 : " + eAssert.message);
    if(eAssert.expected) console.error("\t期望值 : " + eAssert.expected);
    if(eAssert.actual) console.error("\t实际值 : " + eAssert.actual);
    process.exit(256);
}
console.log("config.json 参数检查完毕");

process.program = config.program;
process.MCD = require("minecraft-data")(config.program.mcver);

const IceBot = require("../botcore/icebot");
const BluePrint = require("../blueprint/blueprint");
const { Path } = require("../blueprint/path");

require("../log");

let fname = process.argv[3];
if (fname == undefined) {
    console.log("未指定冰机定义文件, 仅启动机器人");
    const bot = new IceBot(config.bot);
} else {
    if (!fname.endsWith(".json")) fname += ".json";
    fname = "./blueprints/" + fname;
    let text = undefined;
    try {
        text = fs.readFileSync(fname, "utf8");
    } catch {
        console.error("未能打开文件" + fname);
        process.exit(1);
    }
    let path;
    try {
        path = new Path(BluePrint.fromAny(JSON.parse(text)));
    } catch (e) {
        console.error("生成路径失败 : " + e.message);
        process.exit(1);
    }
    process.on("exit", (code) => {
        console.log("Ice Bot exit with code " + code);
    });
    process.on("uncaughtException", (err) => {
        console.log(err);
    });

    const bot = new IceBot(config.bot, [require("./message")]);
    bot.path = path;
    bot.history.start();
    require("../display/server")(bot);
}
