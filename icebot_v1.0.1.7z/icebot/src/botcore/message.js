const IceBot = require("./icebot");
const command = require("./command");
/**
 * @description 迁移指南：需要根据不同的服务器消息格式实现特定的 消息转换器(MsgConvertor). 每次机器人接收到消息(jsonMsg格式),
 *  转换器需要过滤该消息是否需要被解析为指令，如果需要，则转换器要调用 onMsgRecv 函数并传入 发送者 和 消息内容
 */

function moleanMsgConvertor(jsonMsg) {
    if (jsonMsg?.text?.startsWith("§7")) {
        const sender = jsonMsg.text.split(" §7-> ")[0].slice(2);
        const text = jsonMsg.extra[0].text;
        onMsgRecv(sender, text);
    }
}

function localServerMsgConverter(jsonMsg) {
    if (jsonMsg.translate == "%s whispers to you: %s") {
        const sender = jsonMsg.with[0].text;
        const text = jsonMsg.with[1].text;
        onMsgRecv(sender, text);
    }
}

/**
 * 接收到有效消息时调用
 * @param {string} sender 发送者
 * @param {string} text 消息内容
 */
function onMsgRecv(sender, text) {
    if (sender == _icebot.config.username) return;
    if (!_icebot.config.masters.includes(sender)) {
        return _icebot.privateMsg(sender, "您没有操控此机器人的权限");
    }
    console.log(sender + " : " + text);
    let words = text.trim().toLowerCase().split(/\s+/);
    if (command[words[0]]) {
        command[words[0]](_icebot, sender, words.slice(1));
    } else _icebot.privateMsg(sender, "未定义的指令 : " + words[0]);
}

/**
 * @type {Icebot}
 */
let _icebot;

/**
 * @param {IceBot} icebot
 */
module.exports = function inject(icebot) {
    _icebot = icebot;
    let msgConverter = localServerMsgConverter;
    if (!process.program.localGame) msgConverter = moleanMsgConvertor;
    icebot.bot.on("message", msgConverter);
};
