const assert = require("assert");
const Util = require("../util");
const ice_id = process.MCD.blocksByName["ice"].id;

const tps = 20;
const delta = 0.15;

/**
 * Move to a block while looking at a fixed direction.
 * @param {import("mineflayer").Bot} bot instance of the bot
 * @param {number} X
 * @param {number} Z
 * @param {number} speed m/tick
 * @returns {Promise<boolean>}
 */
async function xzMove(bot, X, Z, speed) {
    const start = bot.entity.position;
    const dX = X - start.x;
    const dZ = Z - start.z;
    const N = Math.ceil(Math.sqrt(dX * dX + dZ * dZ) / (speed / tps));
    const dx = dX / N;
    const dz = dZ / N;
    return new Promise((resolve) => {
        let i = 0;
        let onTick = () => {
            i++;
            let target = start.offset(i * dx, 0, i * dz);
            bot.entity.position = target;
            if (i == N) {
                bot.off("physicsTick", onTick);
                resolve(true);
            }
        };
        bot.on("physicsTick", onTick);
    });
}

/**
 * Move along X or Z axis and dig the ice
 * @param {import("./icebot")} icebot
 * @param {number} intX
 * @param {number} intZ
 */
async function moveDig(icebot, intX, intZ) {
    const dirx = -Math.sin(icebot.facing);
    const dirz = -Math.cos(icebot.facing);
    const dX = intX - Math.floor(icebot.bot.entity.position.x);
    const dZ = intZ - Math.floor(icebot.bot.entity.position.z);
    if (
        !(dX == 0 || Math.abs(dirx) < 0.001) &&
        (dZ == 0 || Math.abs(dirz) < 0.001)
    ) {
        console.error(
            "Moving and digging direction are not orthogonal : " +
                icebot.bot.entity.position +
                " -> " +
                intX +
                "," +
                intZ,
        );
        return false;
    }
    const X = intX + 0.5 + delta * dirx;
    const Z = intZ + 0.5 + delta * dirz;

    let tick_cnt = 0;

    const tryDigIce = async () => {
        if (++tick_cnt % 300 == 0) {
            const item = icebot.bot.heldItem;
            const max = process.MCD.items[item?.type]?.maxDurability;
            icebot.history.currentDurability = max
                ? max - item.durabilityUsed
                : 0;
        }
        if (icebot.bot.targetDigBlock) return;
        const block = icebot.bot.blockAtCursor(5);
        if (block && block.type == ice_id && icebot.bot.canDigBlock(block)) {
            return icebot.bot.dig(block, "ignore").then(icebot.history.add());
        }
    };

    icebot.bot.on("physicsTick", tryDigIce);
    return xzMove(icebot.bot, X, Z, icebot.config.speed.dig).then((result) => {
        icebot.bot.off("physicsTick", tryDigIce);
        return result;
    });
}

/**
 * Move to target position without digging
 * @param {import("./icebot")} icebot
 * @param {number} intX
 * @param {number} intZ
 */
async function feed(icebot, intX, intZ) {
    const dirx = -Math.sin(icebot.facing);
    const dirz = -Math.cos(icebot.facing);
    return xzMove(
        icebot.bot,
        intX + 0.5 + delta * dirx,
        intZ + 0.5 + delta * dirz,
        icebot.config.speed.feed,
    );
}

module.exports = { feed, moveDig };
