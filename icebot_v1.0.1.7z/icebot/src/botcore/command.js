const IceBot = require("./icebot");
const { delay } = require("../util");
const equipPickaxe = require("./pickaxe");

function report(icebot, sender, message) {
    if (icebot.bot.players[sender]) {
        icebot.bot.chat(`/tell ${sender} ${message}`);
    } else icebot.bot.chat(`致 ${sender} : ${message}`);
    console.log("命令返回 : " + message);
}

/**
 * @type {((icebot:IceBot, sender:string, args:string[])=>void)[]}
 */
module.exports = {
    /**
     *
     * @param {IceBot} icebot
     * @param {string} sender
     * @param {string[]} args
     */
    checktool: (icebot, sender, args) => {
        equipPickaxe(icebot).then((isok)=>{
            if(isok){
                const tool = icebot.bot.heldItem;
                report(icebot, sender, `装备了${tool.name}, 耐久${tool.maxDurability - tool.durabilityUsed} / ${tool.maxDurability}`);
            }
            else report(icebot, sender, "未能装备任何工具")
        })
    },

    say: (icebot, sender, args) => {
        const text = args.join(" ");
        icebot.bot.chat(text);
        report(icebot, sender, "已发送 : " + text);
    },

    toss: async (icebot, sender, args) => {
        let items = icebot.bot.inventory.items();
        const ice = process.MCD.itemsByName["ice"].id;
        const netherite_pickaxe =
            process.MCD.itemsByName["netherite_pickaxe"].id;
        const diamond_pickaxe = process.MCD.itemsByName["diamond_pickaxe"].id;
        switch (args[0]) {
            case "ice":
                items = items.filter((item) => item.type == ice);
                break;
            case "tool":
                items = items.filter(
                    (item) =>
                        item.type == netherite_pickaxe ||
                        item.type == diamond_pickaxe,
                );
                break;
            case "else":
                items = items.filter(
                    (item) =>
                        item.type != netherite_pickaxe &&
                        item.type != diamond_pickaxe &&
                        item.id != ice,
                );
                break;
            case "all":
                break;
            default:
                return report(icebot, sender, "参数不存在");
        }
        for (const item of items) {
            await icebot.bot.tossStack(item);
        }
        return report(icebot, sender, `丢出了 ${items.length} 组物品`);
    },

    stop: (icebot, sender, args) => {
        const shutdown = async () => {
            await delay(5000);
            icebot.bot.quit("Intentional");
            await delay(1000);
            console.log("工作进程计划退出");
            process.exit(256);
        };
        if (icebot.shutdown && args[0] != "reset")
            return report(
                icebot,
                sender,
                "未能设置计划 : 已存在停机计划或已停机",
            );
        switch (args[0]) {
            case "loop":
            case undefined:
                icebot.on("loopFinish", shutdown);
                report(icebot, sender, "计划在本次循环之后停机");
                icebot.shutdown = "loopFinish";
                break;
            case "motion":
                icebot.on("motionStart", shutdown);
                report(icebot, sender, "计划在本次运动完成或失败之后停机");
                icebot.shutdown = "motionStart";
                break;
            case "now":
                const now = Date.now();
                if (this.danger || now - this.danger > 15000) {
                    this.danger = now;
                    report(
                        icebot,
                        sender,
                        "立即停机是危险行为，请在15s内重复指令作为确认",
                    );
                }
                this.danger = undefined;
                report(icebot, sender, "发送即刻停机指令");
                icebot.bot.quit("Intentional");
                return;
            case "reset":
                if (icebot.shutdown == undefined)
                    return report(
                        icebot,
                        sender,
                        "未能取消计划 : 没有计划中的停机",
                    );
                if (icebot.shutdown == "ok")
                    return report(
                        icebot,
                        sender,
                        "未能取消计划 : 停机已经发生",
                    );
                else if (icebot.off(icebot.shutdown, shutdown))
                    return report(icebot, sender, "成功取消计划");
            default:
                report(icebot, sender, "指令不存在");
        }
    },
};
