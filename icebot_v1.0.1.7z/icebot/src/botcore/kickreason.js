const translation = {
    "disconnect.closed": "连接已关闭",
    "disconnect.disconnected": "被服务器中断连接",
    "disconnect.endOfStream": "数据流终止",
    "disconnect.exceeded_packet_rate": "由于超出数据包速率限制而被踢出游戏",
    "disconnect.kicked": "你已被踢出游戏",
    "disconnect.loginFailed": "登录失败",
    "disconnect.loginFailedInfo.insufficientPrivileges": "多人游戏已被禁用，请检查你的Microsoft账户设置。",
    "disconnect.loginFailedInfo.invalidSession": "无效会话（请尝试重启游戏及启动器）",
    "disconnect.loginFailedInfo.serversUnavailable": "暂时无法连接到身份验证服务器，请稍后再试。",
    "disconnect.loginFailedInfo.userBanned": "你已被禁止进行多人游戏",
    "disconnect.lost": "连接已丢失",
    "disconnect.overflow": "缓冲区溢出",
    "disconnect.quitting": "退出",
    "disconnect.spam": "由于滥发消息而被踢出游戏",
    "disconnect.timeout": "连接超时",
    "disconnect.unknownHost": "未知的主机",
    "multiplayer.disconnect.closed": "连接已关闭",
    "multiplayer.disconnect.disconnected": "被服务器中断连接",
    "multiplayer.disconnect.endOfStream": "数据流终止",
    "multiplayer.disconnect.exceeded_packet_rate": "由于超出数据包速率限制而被踢出游戏",
    "multiplayer.disconnect.kicked": "你已被踢出游戏",
    "multiplayer.disconnect.loginFailed": "登录失败",
    "multiplayer.disconnect.loginFailedInfo.insufficientPrivileges": "多人游戏已被禁用，请检查你的Microsoft账户设置。",
    "multiplayer.disconnect.loginFailedInfo.invalidSession": "无效会话（请尝试重启游戏及启动器）",
    "multiplayer.disconnect.loginFailedInfo.serversUnavailable": "暂时无法连接到身份验证服务器，请稍后再试。",
    "multiplayer.disconnect.loginFailedInfo.userBanned": "你已被禁止进行多人游戏",
    "multiplayer.disconnect.lost": "连接已丢失",
    "multiplayer.disconnect.overflow": "缓冲区溢出",
    "multiplayer.disconnect.quitting": "退出",
    "multiplayer.disconnect.spam": "由于滥发消息而被踢出游戏",
    "multiplayer.disconnect.timeout": "连接超时",
    "multiplayer.disconnect.unknownHost": "未知的主机",
};

function getString(reason) {
    let obj = JSON.parse(reason);
    if ("text" in obj) return obj.text;
    if ("translate" in obj) {
        if (obj.translate in translation) return translation[obj.translate];
    }
    return reason;
}

module.exports = getString;
