const PointXZ = require("../blueprint/pointxz");
const { delay } = require("../util");
const { moveDig, feed } = require("./motion");
const equipPickaxe = require("./pickaxe");
const Vec3 = require("vec3").Vec3;

let working = false;

/**
 * @description RTB 是每次机器人完成挖冰之后进行的操作（包括回到原点），根据服务器不同，应当执行不同的行为。
 * 默认RTB函数如同
 */
let RTB = async (icebot) => {
    icebot.bot.chat(
        `/tp ${icebot.path.origin.x} ${icebot.path.is} ${icebot.path.origin.z}`,
    );
};

if (!process.program.localGame)
    RTB = async (icebot) => {
        console.log("前往 #1 白嫖恢复");
        icebot.bot.chat("/visit id 1");
        do {
            await delay(1000);
        } while (!(icebot.bot.health == 20 && icebot.bot.foodSaturation == 20));
        icebot.bot.chat(`/visit id ${icebot.path.is}`);
        console.log("白嫖完毕");
        await delay(1000);
    };

/**
 * 执行完整的挖冰任务
 * @param {import("./icebot")} icebot
 */
async function doWork(icebot) {
    icebot.syncEmit("workStart");
    while (1) {
        await icebot.syncEmit("loopStart");
        while (icebot.path.stage < icebot.path.count) {
            if (!working) {
                icebot.syncEmit("workEnd");
                return;
            }
            await icebot.syncEmit("motionStart");
            const line = icebot.path.lines[icebot.path.stage];
            let result;
            if (line.dig)
                result = await moveDig(icebot, line.targetX, line.targetZ);
            else result = await feed(icebot, line.targetX, line.targetZ);
            console.debug(
                `成功完成运动${icebot.path.stage}: ${
                    line.dig ? "工作" : "进给"
                } {${line.targetX}, ${line.targetZ}}`,
            );
            if (!result) {
                console.warn(
                    `未能成功完成目标{x:${line.targetX}, z:${line.targetZ}}的运动`,
                );
                continue;
            }
            icebot.path.stage++;
        }
        icebot.path.loop++;
        icebot.path.stage = 0;
        console.log(`第${icebot.path.loop}次工作循环完成`);
        await icebot.syncEmit("loopFinish");
        let sleep = parseFloat(icebot.path.extra.loopDelay);
        if (!isNaN(sleep)) {
            console.log(`下一次工作循环在 ${sleep}s 之后开始`);
            await delay(sleep * 1000);
        }
        if (!(await prepare(icebot))) return;
    }
}

/**
 * 找到合适的装备，返回起点
 * @param {import("./icebot")} icebot
 * @param {boolean} gotoOrigin
 */
async function prepare(icebot, gotoOrigin = true) {
    working = false;
    if (icebot.path == undefined) {
        console.warn("<prepare> 任务在准备阶段失败 : 未加载工作路径");
    }
    let equipped = await equipPickaxe(icebot);
    if (!equipped) {
        console.warn("<prepare> 任务在准备阶段失败 : 无法装备挖掘工具");
        return false;
    }
    if (gotoOrigin) {
        await RTB(icebot);
        await delay(1000);
        console.debug("将要开始新循环");
        if (
            !PointXZ.equal(
                PointXZ.fromVec3(icebot.bot.entity.position),
                icebot.path.origin,
            )
        ) {
            console.warn("<prepare> 任务在准备阶段失败 : 岛屿出生点不在冰机原点");
            return false;
        }
    }
    icebot.facing = icebot.path.facing;
    icebot.bot.look(icebot.facing, 0, true);
    working = true;
    return true;
}

/**
 * 当掉线时，自动恢复任务
 * @param {import("./icebot")} icebot
 * @returns
 */
async function resumeWork(icebot) {
    console.log("尝试重新恢复任务");
    if (!(await prepare(icebot, false))) {
        console.error("未能恢复任务状态");
        return;
    };
    if(process.program.useNeeko) await reconnectNeeko(icebot);
    console.log("在最晚检查点重启工作循环");
    return doWork(icebot);
}

async function reconnectNeeko(icebot){
    const sendSwap = function(icebot){
        icebot.bot._client.write("block_dig",{
            status: 6,
            location: new Vec3(0,0,0),
            face: 0
        })
    }

    console.log("<fix> 通过末影人neeko技能解决重连无法运动问题");
    await delay(2000);
    await icebot.bot.look(0, -Math.PI / 2, true);
    await delay(1500);
    sendSwap(icebot);
    await delay(500);
    sendSwap(icebot);
    await delay(2000);
    await icebot.bot.look(icebot.facing, 0, true);
}

async function useNeeko(icebot){
    const listenServerMsg = async (timeout)=>{
        const list = [];
        const listen = (jsonMsg)=>{
            if(jsonMsg.text == "§8[§3相关信息§8]") list.push(jsonMsg.extra[0]?.text);
        }
        return new Promise((resolve)=>{
            icebot.bot.on("message", listen);
            setTimeout(() => {
                icebot.bot.off("message", listen);
                return resolve(list);
            }, timeout);
        })
    };

    icebot.bot.chat("/neeko use ENDERMAN");
    const reply = (await listenServerMsg(800)).find((reply) => reply.startsWith("你现在是"))
    if(reply){
        let grade = reply.slice(7,9);
        console.log(`<fix> 成功切换为末影人neeko形象以解决断线重连的运动失效, 等级 ${grade}`);
        process.program.useNeeko = true;
        return true;
    }
    else {
        console.warn("<fix> 未能切换为末影人neeko形象, 可能导致断线重连后运动受阻");
        process.program.useNeeko = false;
        return false;
    }
    
}

module.exports = { doWork, prepare, resumeWork, useNeeko };
