module.exports = class SyncEmitter {
    constructor() {
        this.events = {};
    }

    /**
     * emit a signal, execuate all slots synchronously
     * @param {string} signal
     * @param  {...any} args
     */
    async syncEmit(signal, ...args) {
        const list = this.events[signal];
        let tmp = [];
        if (list)
            for (const item of list) {
                await item.func(...args);
                if (!item.once) tmp.push(item);
            }
        this.events[signal] = tmp;
    }

    /**
     * register a slot that will be executed each time the signal raises
     * @param {string} signal
     * @param {(...) => void | Promise<void>} callback
     */
    on(signal, callback) {
        if (!(signal in this.events)) {
            this.events[signal] = [];
        }
        this.events[signal].push({ once: false, func: callback });
    }

    /**
     * register a slot that will be executed only once
     * @param {string} signal
     * @param {(...) => void | Promise<void>} callback
     */
    once(signal, callback) {
        if (!(signal in this.events)) {
            this.events[signal] = [];
        }
        this.events[signal].push({ once: true, func: callback });
    }

    listenerOf(signal) {
        return this.events[signal];
    }

    removeAllListeners(signal) {
        this.events[signal] == undefined;
    }

    /**
     * unregister a slot
     * @param {string} signal
     * @param {(...) => void | Promise<void>} callback
     */
    off(signal, callback) {
        let ret = false;
        const list = this.events[signal];
        this.events[signal] = [];
        if (list) {
            for (const item of list) {
                if (item.func.name == callback.name) ret = true;
                else this.events[signal].push(item);
            }
        }
        return ret;
    }
};
