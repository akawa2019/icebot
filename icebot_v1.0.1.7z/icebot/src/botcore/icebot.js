const mineflayer = require("mineflayer");
const getKickReason = require("./kickreason");
const { Path } = require("../blueprint/path");
const SyncEmitter = require("./syncEmitter");
const History = require("./history");
const { prepare, doWork, resumeWork ,useNeeko } = require("./dowork");
const messagePlugin = require("./message");


class IceBot extends SyncEmitter {
    /**
     * @type {import("mineflayer").Bot}
     */
    bot;
    facing;
    config;

    /**
     * @type {Path | undefined}
     */
    path;

    constructor(config) {
        super();
        this.config = config;
        this.history = new History();
        process.on("exit", () => {
            this.bot?.quit("Intentional");
        });
        this.initialize();
    }

    initialize() {
        console.log(
            `${this.config.username} 开始连接 ${this.config.host}:${this.config.port}`,
        );
        this.connTimer = setTimeout(() => {
            console.error("<工作进程> 未能在 1min 内重连成功，退出并重启");
            process.exit(-1);
        }, 60000);
        const retry = (error) => {
            clearTimeout(this.connTimer);
            console.error("建立连接错误 (5s后重试) : " + error);
            this.bot.off("error", retry);
            setTimeout(() => {
                this.initialize();
            }, 5000);
        };
        this.bot = mineflayer.createBot({
            host: this.config.host,
            port: this.config.port,
            auth: this.config.auth,
            version: process.program.mcver,
            username: (this.config.auth == "offline") ? this.config.username : this.config.account,
            password: (this.config.auth == "offline") ? this.config.password : undefined,
            
        });
        this.bot.on("error", retry);
        this.bot.once("spawn", () => {
            this.shutdown = undefined;
            this.bot.off("error", retry);
            clearTimeout(this.connTimer);
            this.connTimer = undefined;
            this.bot.once("end", (reason) => {
                if (reason == "Intentional") {
                    console.log("ICEBOT 执行计划停机");
                    this.shutdown = "ok";
                    return;
                }
                console.error(`${this.config.username} 失去连接`);
                setTimeout(() => {
                    this.initialize();
                }, 5000);
            });
            if (this.config.auth == "offline" && !process.program.localGame) {
                this.bot.chat(this.config.password);
            }
            console.log(`${this.config.username} 连接成功`);
            messagePlugin(this);
            this.bot.once("kicked", (reason) => {console.warn(`服务器主动断开 ${this.config.username} : ${getKickReason(reason)}`)});
            if(this.path) this.startOrResume();
        });
    }

    async startOrResume(){
        await useNeeko(this);
        console.log("准备执行任务 : " + this.path.name);
        if(this.path.stage == 0){
            if (await prepare(this, true)) return doWork(this);
        }
        else return resumeWork(this);
    }

    privateMsg(player, message) {
        this.bot.chat(`/tell ${player} ${message}`);
        console.log(`${player} <- ${message}`);
    }
}

module.exports = IceBot;
