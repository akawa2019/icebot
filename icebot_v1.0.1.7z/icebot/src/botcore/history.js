module.exports = class History {
    counter;
    timer;
    production;
    startTime;
    durablity;
    currentDurability = 0;
    firstMin;
    minCount;

    /**
     * 
     * @param {import("./icebot")} icebot 
     */
    constructor(icebot) {
        this.counter = 0;
        this.timer = undefined;
        this.production = [];
        this.durablity = [];
        this.icebot = icebot;
        this.firstMinCount = undefined;
    }

    /**
     * Should run each time an ice is digged
     * @returns the total count after adding
     */
    add() {
        return ++this.counter;
    }

    start() {
        if(this.firstMin) return;
        this.startTime = Date.now();
        this.firstMin = Math.ceil(Date.now() / 60000) * 60000;
        this.minCount = 0;
        this.setMinuteTimer();
    }

    onEachMinute = () => {
        const current = this.counter;
        const minute = current - (this.production[this.production.length - 1] ?? 0);
        this.production.push(current);
        if((this.durablity.at(-1) != this.currentDurability) && process.send) process.send("heartbeat");
        this.durablity.push(this.currentDurability);
        console.log("上一分钟挖冰量 : " + minute + ", 累计挖冰量 : " + this.counter + ", 工具耐久剩余 : " + this.currentDurability);
    };

    setMinuteTimer = () => {
        const timeup = this.firstMin + 60000 * this.minCount - Date.now();
        this.minCount ++;
        this.timer = setTimeout(()=>{this.setMinuteTimer() ;this.onEachMinute();}, timeup);
    }
};
