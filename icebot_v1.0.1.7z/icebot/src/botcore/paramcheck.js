const assert = require("assert");

module.exports = function check(config){
    assert.ok("username" in config.bot, "'bot.username' is not defined in config.json",);
    assert.ok("port" in config.bot, "'bot.port' is not defined in config.json");
    if (config.program.localGame) {
        config.bot.auth = "offline";
        config.bot.host = "127.0.0.1";
        if (config.bot.username.startsWith("#"))
            config.bot.username = config.bot.username.slice(1);
            console.log("<fix> 在本地服务器中，命令的主语和宾语无法输入#开始的玩家，因此将 ICEBOT 实例 username 改为 : " + config.bot.username);
    } else {
        assert.ok("host" in config.bot, "'bot.host' is not defined in config.json");
        if(config.bot.auth) config.bot.auth = config.bot.auth.toLowerCase();
        if (config.bot.auth == "offline") {
            assert.ok(config.bot.username.startsWith("#"), "invalid offline username",);
            assert.ok("password" in config.bot,"'bot.password' is not defined in config.json",
            );
            console.log("<fix> 服务器离线登陆模式仅支持 1.19.2, 锁定 config.json: program.mcver = '1.19.2'");
            config.program.mcver = "1.19.2";
        }
        else if(config.bot.auth == "microsoft") {
            assert.ok(config.bot.account, "'bot.account' is not defined in config.json");
        }
        else{
            throw new assert.AssertionError({message:"invalid 'bot.auth' string in config.json"})
        }
    }
}