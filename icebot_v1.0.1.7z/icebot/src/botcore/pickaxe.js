// Descending priority
const required_pickaxes = ["netherite_pickaxe", "diamond_pickaxe"];

const required_enchants = {
    mending: 1,
    silk_touch: 1,
    unbreaking: 3,
    efficiency: 4,
};

/**
 * equip an pickaxe with some requirements
 * @param {import("../botcore/icebot")} icebot
 */
module.exports = async function equipPickaxe(icebot) {
    let slots = icebot.bot.inventory.items();
    let ok_pickaxe = undefined;
    for (const req_name of required_pickaxes) {
        const req_id = process.MCD.itemsByName[req_name].id;
        ok_pickaxe = slots
            .filter((item) => item.type == req_id)
            .find((pickaxe) => {
                for (const req_enchant in required_enchants) {
                    let found = pickaxe.enchants.find(
                        (enchant) =>
                            enchant.name == req_enchant &&
                            enchant.lvl >= required_enchants[req_enchant],
                    );
                    if (found == undefined) return false;
                }
                return true;
            });
        if (ok_pickaxe) break;
    }
    if (ok_pickaxe) {
        try {
            await icebot.bot.equip(ok_pickaxe, "hand");
        } catch (e) {
            console.warn("找到但未能装备挖掘工具 : " + e);
            return Promise.resolve(false);
        }
        const max_dur = process.MCD.items[ok_pickaxe.type].maxDurability;
        const current = max_dur - ok_pickaxe.durabilityUsed;
        console.log(`成功装备挖掘工具，耐久 : ${current} / ${max_dur}`);
        icebot.history.currentDurability = current;
        return Promise.resolve(true);
    } else {
        console.warn("没有符合要求的挖掘工具");
        return Promise.resolve(false);
    }
};
