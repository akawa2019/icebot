const { readFileSync } = require("fs");
const Process = require("child_process");

const command = process.argv[2];

process.chdir(__dirname + "/..");
process.env.ICEBOT_LOGFILE_NAME = process.cwd() + "/log/" + Date.now() + ".txt";
welcome();
switch (command) {
    case "def":
        require("./blueprint/creatBPcli")().then(() => process.exit(0));
        break;
    case "run":
        if (process.argv[3] == undefined) {
            require("./botcore/workinit");
        }else{
            startWorkingThread();
        }
        break;
    case "help":
        let lines = readFileSync("./doc/help.txt", "utf8").split("\n");
        lines.forEach((line) => console.log(line));
        break;
    default:
        console.warn("错误的启动参数, 使用参数 help 查看帮助");
}

function startWorkingThread() {
    require("./log");
    const worker = Process.fork("./src/botcore/workinit", process.argv.slice(2), { cwd: process.cwd(), silent: false});
    worker.on("exit", (code) => {
        if(code == 256){
            console.log("<监护进程> : 工作进程计划结束, 主进程退出");
            process.exit(0);
        }else{
            console.error("<监护进程> : 工作进程非计划结束, 10s后重启")
            setTimeout(startWorkingThread, 10000);
        }
    })
    process.on("exit", () => {
        worker.off("exit", startWorkingThread);
        worker.kill()
    })
    const timeout = require("../config.json")?.program?.watchdogTimeout;
    if (timeout) {
        const kill = () => {
            worker.kill();
            console.error("<监护进程> : 工作进程长时间未发送心跳,将其结束");
        }
        console.log("设置工作进程无响应重启宽限时间(min) : " + timeout);
        let watchDog = setTimeout(kill, timeout * 60000)
        worker.on("message", (message) => {
            if (message == "heartbeat") watchDog.refresh();
        })
    }
    else console.log("未启动工作进程无响应自动重启功能");
}

function welcome(){
    console.log("ICEBOT v1.0 starting...");
    console.log("日志将记录于 : " + process.env.ICEBOT_LOGFILE_NAME);
    console.log("控制台不带时间信息的输出将不被记录");
}
