/**
 * 警告: 加载本脚本将全局性修改 nodejs 的 console
 * 将其 log, warn, error 增加输出时间以及写入日志文件的功能
 */
const fs = require("fs");
const debug = process?.program?.debug ?? false;

const logfile = process.env.ICEBOT_LOGFILE_NAME;
const timestamp = () => `[${new Date().toLocaleTimeString("zh-CN")}]`;

console._log = console.log;
console._warn = console.warn;
console._error = console.error;

if (debug) {
    console.debug = function (msg) {
        const text = timestamp() + " [debug] " + msg;
        console._log(text);
        fs.appendFile(logfile, text + "\n", undefined, () => {});
    };
} else{
    console.debug = function (any) {};
}

console.log = function (msg) {
    const text = timestamp() + " [info]  " + msg;
    console._log(text);
    fs.appendFile(logfile, text + "\n", undefined, () => {});
};

console.warn = function (msg) {
    const text = timestamp() + " [warn]  " + msg;
    console._warn(text);
    fs.appendFile(logfile, text + "\n", undefined, () => {});
};

console.error = function (msg) {
    const text = timestamp() + " [error] " + msg;
    console._error(text);
    fs.appendFile(logfile, text + "\n", undefined, () => {});
};


